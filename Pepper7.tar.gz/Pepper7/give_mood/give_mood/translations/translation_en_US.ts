<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Aucune idée !</source>
            <comment>Text</comment>
            <translation type="obsolete">Aucune idée !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tu n'es ni triste ni joyeux, plutôt neutre</source>
            <comment>Text</comment>
            <translation type="obsolete">Tu n'es ni triste ni joyeux, plutôt neutre</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tu as l'air très content !</source>
            <comment>Text</comment>
            <translation type="obsolete">Tu as l'air très content !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tu sembles surpris</source>
            <comment>Text</comment>
            <translation type="obsolete">Tu sembles surpris</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tu as l'air tout triste, je peux faire quelque chose pour toi ?</source>
            <comment>Text</comment>
            <translation type="obsolete">Tu as l'air tout triste, je peux faire quelque chose pour toi ?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tu es en colère, j'espère que je n'ai pas fait de bêtises !</source>
            <comment>Text</comment>
            <translation type="obsolete">Tu es en colère, j'espère que je n'ai pas fait de bêtises !</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Aucune idée !</source>
            <comment>Text</comment>
            <translation type="unfinished">Aucune idée !</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (1)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu n'es ni triste ni joyeux, plutôt neutre</source>
            <comment>Text</comment>
            <translation type="unfinished">Tu n'es ni triste ni joyeux, plutôt neutre</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (2)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu as l'air très content !</source>
            <comment>Text</comment>
            <translation type="unfinished">Tu as l'air très content !</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (3)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu sembles surpris</source>
            <comment>Text</comment>
            <translation type="unfinished">Tu sembles surpris</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (4)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu as l'air tout triste, je peux faire quelque chose pour toi ?</source>
            <comment>Text</comment>
            <translation type="unfinished">Tu as l'air tout triste, je peux faire quelque chose pour toi ?</translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (5)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu es en colère, j'espère que je n'ai pas fait de bêtises !</source>
            <comment>Text</comment>
            <translation type="unfinished">Tu es en colère, j'espère que je n'ai pas fait de bêtises !</translation>
        </message>
    </context>
</TS>
