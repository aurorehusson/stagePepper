<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Alors, c'était quel animal ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Bravo, je suis une souris !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Non, je suis une souris !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (3)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Alors, c'était quel animal ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (4)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Alors, c'était quel animal ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (5)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Bravo, je suis un gorille !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (6)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Non, je suis un gorille !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (7)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Bravo, je suis un éléphant !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>imitate_animal/behavior.xar:/Animated Say (8)</name>
        <message>
            <location filename="imitate_animal/behavior.xar" line="0"/>
            <source>Non, je suis un éléphant !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
