<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Jusqu'à combien veux-tu que je compte ?</source>
            <comment>Text</comment>
            <translation type="obsolete">Jusqu'à combien veux-tu que je compte ?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Désolé, je ne sais compter que jusqu'à 10. Jusqu'à combien veux-tu que je compte ?</source>
            <comment>Text</comment>
            <translation type="obsolete">Désolé, je ne sais compter que jusqu'à 10. Jusqu'à combien veux-tu que je compte ?</translation>
        </message>
    </context>
    <context>
        <name>count/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="count/behavior.xar" line="0"/>
            <source>Terminé !</source>
            <comment>Text</comment>
            <translation type="unfinished">Terminé !</translation>
        </message>
    </context>
    <context>
        <name>count/behavior.xar:/Say</name>
        <message>
            <source>Jusqu'à combien veux-tu que je compte ?</source>
            <comment>Text</comment>
            <translation type="obsolete">Jusqu'à combien veux-tu que je compte ?</translation>
        </message>
    </context>
    <context>
        <name>count/behavior.xar:/Say (1)</name>
        <message>
            <source>Désolé, je ne sais compter que jusqu'à 10. Jusqu'à combien veux-tu que je compte ?</source>
            <comment>Text</comment>
            <translation type="obsolete">Désolé, je ne sais compter que jusqu'à 10. Jusqu'à combien veux-tu que je compte ?</translation>
        </message>
    </context>
</TS>
