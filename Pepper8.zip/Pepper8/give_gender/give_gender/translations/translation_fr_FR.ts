<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>guess_gender/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="guess_gender/behavior.xar" line="0"/>
            <source>Je crois bien que tu es une fille. Est-ce que j'ai raison ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>guess_gender/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="guess_gender/behavior.xar" line="0"/>
            <source>Tu dois être un garçon. Est-ce que j'ai raison ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>guess_gender/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="guess_gender/behavior.xar" line="0"/>
            <source>C'était facile à deviner</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>guess_gender/behavior.xar:/Animated Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="guess_gender/behavior.xar" line="0"/>
            <source>Oh ohhh je me suis trompé</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>guess_gender/behavior.xar:/Animated Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="guess_gender/behavior.xar" line="0"/>
            <source>Désolé, je ne sais pas bien</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
