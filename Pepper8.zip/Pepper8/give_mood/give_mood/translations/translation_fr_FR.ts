<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>say_mood/behavior.xar:/Animated Say</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Aucune idée !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (1)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu n'es ni triste ni joyeux, plutôt neutre</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (2)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu as l'air très content !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (3)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu sembles surpris</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (4)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu as l'air tout triste, je peux faire quelque chose pour toi ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>say_mood/behavior.xar:/Animated Say (5)</name>
        <message>
            <location filename="say_mood/behavior.xar" line="0"/>
            <source>Tu es en colère, j'espère que je n'ai pas fait de bêtises !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
