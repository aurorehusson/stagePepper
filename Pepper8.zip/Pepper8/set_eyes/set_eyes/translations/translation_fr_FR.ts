<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>set_color/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>Quelle couleur tu voudrais ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>rouge</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>bleu</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>Okay, c'est tout pour aujourd'hui</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>vert</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>violet</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>orange</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (6)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>jaune</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (7)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>blanc</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>set_color/behavior.xar:/Say (8)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>rose</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
