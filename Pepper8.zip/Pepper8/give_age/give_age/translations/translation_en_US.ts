<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>guess_age/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="guess_age/behavior.xar" line="0"/>
            <source>Oups, je me suis trompé</source>
            <comment>Text</comment>
            <translation type="unfinished">Oups, je me suis trompé</translation>
        </message>
    </context>
    <context>
        <name>guess_age/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Je le savais !</source>
            <comment>Text</comment>
            <translation type="obsolete">Je le savais !</translation>
        </message>
        <message>
            <location filename="guess_age/behavior.xar" line="0"/>
            <source>J'en étais sûr !</source>
            <comment>Text</comment>
            <translation type="unfinished">J'en étais sûr !</translation>
        </message>
    </context>
    <context>
        <name>guess_age/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="guess_age/behavior.xar" line="0"/>
            <source>Je vais essayer de deviner ton âge</source>
            <comment>Text</comment>
            <translation type="unfinished">Je vais essayer de deviner ton âge</translation>
        </message>
    </context>
    <context>
        <name>guess_age/behavior.xar:/Animated Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="guess_age/behavior.xar" line="0"/>
            <source>Non, je ne trouve pas</source>
            <comment>Text</comment>
            <translation type="unfinished">Non, je ne trouve pas</translation>
        </message>
    </context>
</TS>
