<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>erase_faces/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="erase_faces/behavior.xar" line="0"/>
            <source>Désolé, je n'ai pas réussi</source>
            <comment>Text</comment>
            <translation type="unfinished">Désolé, je n'ai pas réussi</translation>
        </message>
    </context>
    <context>
        <name>erase_faces/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="erase_faces/behavior.xar" line="0"/>
            <source>Ok, je ne me souviens plus des visages</source>
            <comment>Text</comment>
            <translation type="unfinished">Ok, je ne me souviens plus des visages</translation>
        </message>
    </context>
    <context>
        <name>erase_one_face/behavior.xar:/Say</name>
        <message>
            <location filename="erase_one_face/behavior.xar" line="0"/>
            <source>Désolé, je n'ai pas réussi</source>
            <comment>Text</comment>
            <translation type="unfinished">Désolé, je n'ai pas réussi</translation>
        </message>
    </context>
    <context>
        <name>erase_one_face/behavior.xar:/Say (1)</name>
        <message>
            <location filename="erase_one_face/behavior.xar" line="0"/>
            <source>Ok, je ne me souviens plus de ton visage</source>
            <comment>Text</comment>
            <translation type="unfinished">Ok, je ne me souviens plus de ton visage</translation>
        </message>
    </context>
    <context>
        <name>learn_face/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="learn_face/behavior.xar" line="0"/>
            <source>J'ai bien appris à reconnaître ton visage !</source>
            <comment>Text</comment>
            <translation type="unfinished">J'ai bien appris à reconnaître ton visage !</translation>
        </message>
    </context>
    <context>
        <name>learn_face/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="learn_face/behavior.xar" line="0"/>
            <source>Désolé, je n'ai pas réussi</source>
            <comment>Text</comment>
            <translation type="unfinished">Désolé, je n'ai pas réussi</translation>
        </message>
    </context>
    <context>
        <name>learn_face/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>learn_face/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>learn_face/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>meet_face/behavior.xar:/Animated Say</name>
        <message>
            <source>J'ai bien appris à reconnaître ton visage !</source>
            <comment>Text</comment>
            <translation type="obsolete">J'ai bien appris à reconnaître ton visage !</translation>
        </message>
    </context>
    <context>
        <name>meet_face/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Désolé, je n'ai pas réussi</source>
            <comment>Text</comment>
            <translation type="obsolete">Désolé, je n'ai pas réussi</translation>
        </message>
    </context>
    <context>
        <name>meet_face/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>D'accord, une prochaine fois alors</source>
            <comment>Text</comment>
            <translation type="obsolete">D'accord, une prochaine fois alors</translation>
        </message>
    </context>
</TS>
