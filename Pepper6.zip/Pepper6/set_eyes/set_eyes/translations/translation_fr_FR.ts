<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>set_color/behavior.xar:/Animated Say</name>
        <message>
            <location filename="set_color/behavior.xar" line="0"/>
            <source>Quelle couleur tu voudrais ?</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
