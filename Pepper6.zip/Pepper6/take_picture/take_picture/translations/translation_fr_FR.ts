<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>one_picture/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="one_picture/behavior.xar" line="0"/>
            <source>Okay</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>one_picture/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="one_picture/behavior.xar" line="0"/>
            <source>D'accord, je l'envoie</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>one_picture/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="one_picture/behavior.xar" line="0"/>
            <source>C'est envoyé !</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>one_picture/behavior.xar:/Animated Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Bonjour</translation>
        </message>
        <message>
            <location filename="one_picture/behavior.xar" line="0"/>
            <source>Désolé, je n'ai pas réussi à l'envoyer</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
